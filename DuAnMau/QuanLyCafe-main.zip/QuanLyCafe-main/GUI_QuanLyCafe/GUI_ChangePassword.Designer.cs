﻿
namespace GUI_QuanLyCafe
{
    partial class ChangePassword_frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChangePassword_frm));
            this.AgainNewPassword_txt = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ShowHideOP_ckb = new System.Windows.Forms.CheckBox();
            this.ShowHideNP_ckb = new System.Windows.Forms.CheckBox();
            this.ShowHideANP_ckb = new System.Windows.Forms.CheckBox();
            this.NewPassword_txt = new System.Windows.Forms.TextBox();
            this.OldPassword_txt = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.DoiMK_grb = new System.Windows.Forms.GroupBox();
            this.Change_btn = new Guna.UI2.WinForms.Guna2Button();
            this.ShowANP_ptb = new System.Windows.Forms.PictureBox();
            this.ShowNP_ptb = new System.Windows.Forms.PictureBox();
            this.HideANP_ptb = new System.Windows.Forms.PictureBox();
            this.ShowOP_ptb = new System.Windows.Forms.PictureBox();
            this.HideNP_ptb = new System.Windows.Forms.PictureBox();
            this.HideOP_ptb = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.DoiMK_grb.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShowANP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowNP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideANP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowOP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideNP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideOP_ptb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.SuspendLayout();
            // 
            // AgainNewPassword_txt
            // 
            this.AgainNewPassword_txt.BackColor = System.Drawing.SystemColors.Window;
            this.AgainNewPassword_txt.Location = new System.Drawing.Point(217, 153);
            this.AgainNewPassword_txt.Name = "AgainNewPassword_txt";
            this.AgainNewPassword_txt.Size = new System.Drawing.Size(270, 32);
            this.AgainNewPassword_txt.TabIndex = 3;
            this.AgainNewPassword_txt.UseSystemPasswordChar = true;
            this.AgainNewPassword_txt.TextChanged += new System.EventHandler(this.AgainNewPassword_txt_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(50, 156);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(161, 23);
            this.label3.TabIndex = 12;
            this.label3.Text = "Nhập lại mật khẩu";
            // 
            // ShowHideOP_ckb
            // 
            this.ShowHideOP_ckb.AutoSize = true;
            this.ShowHideOP_ckb.BackColor = System.Drawing.Color.Transparent;
            this.ShowHideOP_ckb.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ShowHideOP_ckb.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShowHideOP_ckb.Location = new System.Drawing.Point(493, 43);
            this.ShowHideOP_ckb.Name = "ShowHideOP_ckb";
            this.ShowHideOP_ckb.Size = new System.Drawing.Size(54, 27);
            this.ShowHideOP_ckb.TabIndex = 8;
            this.ShowHideOP_ckb.TabStop = false;
            this.ShowHideOP_ckb.Text = "     ";
            this.ShowHideOP_ckb.UseVisualStyleBackColor = false;
            this.ShowHideOP_ckb.CheckedChanged += new System.EventHandler(this.ShowHideOP_ckb_CheckedChanged);
            // 
            // ShowHideNP_ckb
            // 
            this.ShowHideNP_ckb.AutoSize = true;
            this.ShowHideNP_ckb.BackColor = System.Drawing.Color.Transparent;
            this.ShowHideNP_ckb.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ShowHideNP_ckb.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShowHideNP_ckb.Location = new System.Drawing.Point(493, 99);
            this.ShowHideNP_ckb.Name = "ShowHideNP_ckb";
            this.ShowHideNP_ckb.Size = new System.Drawing.Size(54, 27);
            this.ShowHideNP_ckb.TabIndex = 8;
            this.ShowHideNP_ckb.TabStop = false;
            this.ShowHideNP_ckb.Text = "     ";
            this.ShowHideNP_ckb.UseVisualStyleBackColor = false;
            this.ShowHideNP_ckb.CheckedChanged += new System.EventHandler(this.ShowHideNP_ckb_CheckedChanged);
            // 
            // ShowHideANP_ckb
            // 
            this.ShowHideANP_ckb.AutoSize = true;
            this.ShowHideANP_ckb.BackColor = System.Drawing.Color.Transparent;
            this.ShowHideANP_ckb.ForeColor = System.Drawing.SystemColors.ControlText;
            this.ShowHideANP_ckb.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ShowHideANP_ckb.Location = new System.Drawing.Point(493, 161);
            this.ShowHideANP_ckb.Name = "ShowHideANP_ckb";
            this.ShowHideANP_ckb.Size = new System.Drawing.Size(54, 27);
            this.ShowHideANP_ckb.TabIndex = 8;
            this.ShowHideANP_ckb.TabStop = false;
            this.ShowHideANP_ckb.Text = "     ";
            this.ShowHideANP_ckb.UseVisualStyleBackColor = false;
            this.ShowHideANP_ckb.CheckedChanged += new System.EventHandler(this.ShowHideANP_ckb_CheckedChanged);
            // 
            // NewPassword_txt
            // 
            this.NewPassword_txt.BackColor = System.Drawing.SystemColors.Window;
            this.NewPassword_txt.Location = new System.Drawing.Point(217, 94);
            this.NewPassword_txt.Name = "NewPassword_txt";
            this.NewPassword_txt.Size = new System.Drawing.Size(270, 32);
            this.NewPassword_txt.TabIndex = 2;
            this.NewPassword_txt.UseSystemPasswordChar = true;
            this.NewPassword_txt.TextChanged += new System.EventHandler(this.NewPassword_txt_TextChanged);
            // 
            // OldPassword_txt
            // 
            this.OldPassword_txt.BackColor = System.Drawing.SystemColors.Window;
            this.OldPassword_txt.Location = new System.Drawing.Point(217, 40);
            this.OldPassword_txt.Name = "OldPassword_txt";
            this.OldPassword_txt.Size = new System.Drawing.Size(270, 32);
            this.OldPassword_txt.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(50, 43);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "Mật khẩu cũ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(50, 97);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 23);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mật khẩu mới";
            // 
            // DoiMK_grb
            // 
            this.DoiMK_grb.BackColor = System.Drawing.Color.Transparent;
            this.DoiMK_grb.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.DoiMK_grb.Controls.Add(this.Change_btn);
            this.DoiMK_grb.Controls.Add(this.AgainNewPassword_txt);
            this.DoiMK_grb.Controls.Add(this.label3);
            this.DoiMK_grb.Controls.Add(this.ShowANP_ptb);
            this.DoiMK_grb.Controls.Add(this.ShowNP_ptb);
            this.DoiMK_grb.Controls.Add(this.HideANP_ptb);
            this.DoiMK_grb.Controls.Add(this.ShowOP_ptb);
            this.DoiMK_grb.Controls.Add(this.HideNP_ptb);
            this.DoiMK_grb.Controls.Add(this.HideOP_ptb);
            this.DoiMK_grb.Controls.Add(this.ShowHideOP_ckb);
            this.DoiMK_grb.Controls.Add(this.ShowHideNP_ckb);
            this.DoiMK_grb.Controls.Add(this.ShowHideANP_ckb);
            this.DoiMK_grb.Controls.Add(this.NewPassword_txt);
            this.DoiMK_grb.Controls.Add(this.OldPassword_txt);
            this.DoiMK_grb.Controls.Add(this.label1);
            this.DoiMK_grb.Controls.Add(this.label2);
            this.DoiMK_grb.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DoiMK_grb.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.DoiMK_grb.Location = new System.Drawing.Point(34, 122);
            this.DoiMK_grb.Name = "DoiMK_grb";
            this.DoiMK_grb.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.DoiMK_grb.Size = new System.Drawing.Size(573, 260);
            this.DoiMK_grb.TabIndex = 8;
            this.DoiMK_grb.TabStop = false;
            this.DoiMK_grb.Text = "Đổi mật khẩu";
            // 
            // Change_btn
            // 
            this.Change_btn.Animated = true;
            this.Change_btn.BorderRadius = 10;
            this.Change_btn.BorderThickness = 2;
            this.Change_btn.CheckedState.Parent = this.Change_btn;
            this.Change_btn.CustomImages.Parent = this.Change_btn;
            this.Change_btn.FillColor = System.Drawing.Color.White;
            this.Change_btn.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Change_btn.ForeColor = System.Drawing.Color.Black;
            this.Change_btn.HoverState.Parent = this.Change_btn;
            this.Change_btn.Image = global::GUI_QuanLyCafe.Properties.Resources.padlock;
            this.Change_btn.Location = new System.Drawing.Point(332, 204);
            this.Change_btn.Name = "Change_btn";
            this.Change_btn.ShadowDecoration.Parent = this.Change_btn;
            this.Change_btn.Size = new System.Drawing.Size(155, 40);
            this.Change_btn.TabIndex = 154;
            this.Change_btn.Text = "Đổi mật khẩu";
            this.Change_btn.Click += new System.EventHandler(this.Change_btn_Click);
            // 
            // ShowANP_ptb
            // 
            this.ShowANP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.eye;
            this.ShowANP_ptb.Location = new System.Drawing.Point(517, 157);
            this.ShowANP_ptb.Name = "ShowANP_ptb";
            this.ShowANP_ptb.Size = new System.Drawing.Size(40, 31);
            this.ShowANP_ptb.TabIndex = 9;
            this.ShowANP_ptb.TabStop = false;
            this.ShowANP_ptb.Visible = false;
            // 
            // ShowNP_ptb
            // 
            this.ShowNP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.eye;
            this.ShowNP_ptb.Location = new System.Drawing.Point(517, 95);
            this.ShowNP_ptb.Name = "ShowNP_ptb";
            this.ShowNP_ptb.Size = new System.Drawing.Size(40, 31);
            this.ShowNP_ptb.TabIndex = 9;
            this.ShowNP_ptb.TabStop = false;
            this.ShowNP_ptb.Visible = false;
            // 
            // HideANP_ptb
            // 
            this.HideANP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.invisible;
            this.HideANP_ptb.Location = new System.Drawing.Point(517, 157);
            this.HideANP_ptb.Name = "HideANP_ptb";
            this.HideANP_ptb.Size = new System.Drawing.Size(40, 31);
            this.HideANP_ptb.TabIndex = 9;
            this.HideANP_ptb.TabStop = false;
            // 
            // ShowOP_ptb
            // 
            this.ShowOP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.eye;
            this.ShowOP_ptb.Location = new System.Drawing.Point(517, 39);
            this.ShowOP_ptb.Name = "ShowOP_ptb";
            this.ShowOP_ptb.Size = new System.Drawing.Size(40, 31);
            this.ShowOP_ptb.TabIndex = 9;
            this.ShowOP_ptb.TabStop = false;
            this.ShowOP_ptb.Visible = false;
            // 
            // HideNP_ptb
            // 
            this.HideNP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.invisible;
            this.HideNP_ptb.Location = new System.Drawing.Point(517, 95);
            this.HideNP_ptb.Name = "HideNP_ptb";
            this.HideNP_ptb.Size = new System.Drawing.Size(40, 31);
            this.HideNP_ptb.TabIndex = 9;
            this.HideNP_ptb.TabStop = false;
            // 
            // HideOP_ptb
            // 
            this.HideOP_ptb.Image = global::GUI_QuanLyCafe.Properties.Resources.invisible;
            this.HideOP_ptb.Location = new System.Drawing.Point(517, 39);
            this.HideOP_ptb.Name = "HideOP_ptb";
            this.HideOP_ptb.Size = new System.Drawing.Size(40, 31);
            this.HideOP_ptb.TabIndex = 9;
            this.HideOP_ptb.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::GUI_QuanLyCafe.Properties.Resources._1200px_Highlands_Coffee_logo_svg;
            this.pictureBox2.Location = new System.Drawing.Point(234, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(172, 119);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 155;
            this.pictureBox2.TabStop = false;
            // 
            // ChangePassword_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(641, 408);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.DoiMK_grb);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "ChangePassword_frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Đổi mật khẩu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ChangePassword_frm_FormClosing);
            this.Load += new System.EventHandler(this.ChangePassword_frm_Load);
            this.DoiMK_grb.ResumeLayout(false);
            this.DoiMK_grb.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ShowANP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowNP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideANP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ShowOP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideNP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HideOP_ptb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TextBox AgainNewPassword_txt;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox ShowANP_ptb;
        private System.Windows.Forms.PictureBox ShowNP_ptb;
        private System.Windows.Forms.PictureBox HideANP_ptb;
        private System.Windows.Forms.PictureBox ShowOP_ptb;
        private System.Windows.Forms.PictureBox HideNP_ptb;
        private System.Windows.Forms.PictureBox HideOP_ptb;
        private System.Windows.Forms.CheckBox ShowHideOP_ckb;
        private System.Windows.Forms.CheckBox ShowHideNP_ckb;
        private System.Windows.Forms.CheckBox ShowHideANP_ckb;
        private System.Windows.Forms.TextBox NewPassword_txt;
        private System.Windows.Forms.TextBox OldPassword_txt;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox DoiMK_grb;
        private Guna.UI2.WinForms.Guna2Button Change_btn;
        private System.Windows.Forms.PictureBox pictureBox2;
    }
}