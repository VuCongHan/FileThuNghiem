﻿
namespace GUI_QuanLyCafe
{
    partial class ListTable_frm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListTable_frm));
            this.ListOrder1_dgv = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Switch_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Merge_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Detach_btn = new Guna.UI2.WinForms.Guna2Button();
            this.Delete_btn = new Guna.UI2.WinForms.Guna2Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.NameTable2_lbl = new System.Windows.Forms.Label();
            this.ListOrder2_dgv = new System.Windows.Forms.DataGridView();
            this.panel1 = new System.Windows.Forms.Panel();
            this.NameTable1_lbl = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.Table_flp = new System.Windows.Forms.FlowLayoutPanel();
            ((System.ComponentModel.ISupportInitialize)(this.ListOrder1_dgv)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListOrder2_dgv)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // ListOrder1_dgv
            // 
            this.ListOrder1_dgv.AllowUserToResizeColumns = false;
            this.ListOrder1_dgv.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ListOrder1_dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.ListOrder1_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ListOrder1_dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ListOrder1_dgv.BackgroundColor = System.Drawing.Color.White;
            this.ListOrder1_dgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenVertical;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ListOrder1_dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.ListOrder1_dgv.ColumnHeadersHeight = 40;
            this.ListOrder1_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ListOrder1_dgv.DefaultCellStyle = dataGridViewCellStyle3;
            this.ListOrder1_dgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ListOrder1_dgv.Location = new System.Drawing.Point(3, 85);
            this.ListOrder1_dgv.MultiSelect = false;
            this.ListOrder1_dgv.Name = "ListOrder1_dgv";
            this.ListOrder1_dgv.ReadOnly = true;
            this.ListOrder1_dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ListOrder1_dgv.RowHeadersVisible = false;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListOrder1_dgv.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.ListOrder1_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ListOrder1_dgv.ShowCellErrors = false;
            this.ListOrder1_dgv.ShowCellToolTips = false;
            this.ListOrder1_dgv.ShowEditingIcon = false;
            this.ListOrder1_dgv.ShowRowErrors = false;
            this.ListOrder1_dgv.Size = new System.Drawing.Size(604, 310);
            this.ListOrder1_dgv.TabIndex = 41;
            this.ListOrder1_dgv.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ListOrder1_dgv_CellClick);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.Switch_btn);
            this.panel3.Controls.Add(this.Merge_btn);
            this.panel3.Controls.Add(this.Detach_btn);
            this.panel3.Controls.Add(this.Delete_btn);
            this.panel3.Controls.Add(this.panel2);
            this.panel3.Controls.Add(this.ListOrder2_dgv);
            this.panel3.Controls.Add(this.panel1);
            this.panel3.Controls.Add(this.ListOrder1_dgv);
            this.panel3.Location = new System.Drawing.Point(667, 9);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(610, 827);
            this.panel3.TabIndex = 19;
            // 
            // Switch_btn
            // 
            this.Switch_btn.Animated = true;
            this.Switch_btn.BorderRadius = 10;
            this.Switch_btn.BorderThickness = 2;
            this.Switch_btn.CheckedState.Parent = this.Switch_btn;
            this.Switch_btn.CustomImages.Parent = this.Switch_btn;
            this.Switch_btn.Enabled = false;
            this.Switch_btn.FillColor = System.Drawing.Color.White;
            this.Switch_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Switch_btn.ForeColor = System.Drawing.Color.Black;
            this.Switch_btn.HoverState.Parent = this.Switch_btn;
            this.Switch_btn.Image = global::GUI_QuanLyCafe.Properties.Resources.exchange;
            this.Switch_btn.Location = new System.Drawing.Point(462, 405);
            this.Switch_btn.Name = "Switch_btn";
            this.Switch_btn.ShadowDecoration.Parent = this.Switch_btn;
            this.Switch_btn.Size = new System.Drawing.Size(145, 40);
            this.Switch_btn.TabIndex = 48;
            this.Switch_btn.Text = "Chuyển bàn";
            this.Switch_btn.Click += new System.EventHandler(this.Switch_btn_Click);
            // 
            // Merge_btn
            // 
            this.Merge_btn.Animated = true;
            this.Merge_btn.BorderRadius = 10;
            this.Merge_btn.BorderThickness = 2;
            this.Merge_btn.CheckedState.Parent = this.Merge_btn;
            this.Merge_btn.CustomImages.Parent = this.Merge_btn;
            this.Merge_btn.Enabled = false;
            this.Merge_btn.FillColor = System.Drawing.Color.White;
            this.Merge_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Merge_btn.ForeColor = System.Drawing.Color.Black;
            this.Merge_btn.HoverState.Parent = this.Merge_btn;
            this.Merge_btn.Image = global::GUI_QuanLyCafe.Properties.Resources.merged;
            this.Merge_btn.Location = new System.Drawing.Point(310, 405);
            this.Merge_btn.Name = "Merge_btn";
            this.Merge_btn.ShadowDecoration.Parent = this.Merge_btn;
            this.Merge_btn.Size = new System.Drawing.Size(145, 40);
            this.Merge_btn.TabIndex = 47;
            this.Merge_btn.Text = "Gộp bàn";
            this.Merge_btn.Click += new System.EventHandler(this.Merge_btn_Click);
            // 
            // Detach_btn
            // 
            this.Detach_btn.Animated = true;
            this.Detach_btn.BorderRadius = 10;
            this.Detach_btn.BorderThickness = 2;
            this.Detach_btn.CheckedState.Parent = this.Detach_btn;
            this.Detach_btn.CustomImages.Parent = this.Detach_btn;
            this.Detach_btn.Enabled = false;
            this.Detach_btn.FillColor = System.Drawing.Color.White;
            this.Detach_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Detach_btn.ForeColor = System.Drawing.Color.Black;
            this.Detach_btn.HoverState.Parent = this.Detach_btn;
            this.Detach_btn.Image = global::GUI_QuanLyCafe.Properties.Resources.remove;
            this.Detach_btn.Location = new System.Drawing.Point(3, 405);
            this.Detach_btn.Name = "Detach_btn";
            this.Detach_btn.ShadowDecoration.Parent = this.Detach_btn;
            this.Detach_btn.Size = new System.Drawing.Size(145, 40);
            this.Detach_btn.TabIndex = 46;
            this.Detach_btn.Text = "Tách bàn";
            this.Detach_btn.Click += new System.EventHandler(this.Detach_btn_Click);
            // 
            // Delete_btn
            // 
            this.Delete_btn.Animated = true;
            this.Delete_btn.BorderRadius = 10;
            this.Delete_btn.BorderThickness = 2;
            this.Delete_btn.CheckedState.Parent = this.Delete_btn;
            this.Delete_btn.CustomImages.Parent = this.Delete_btn;
            this.Delete_btn.FillColor = System.Drawing.Color.White;
            this.Delete_btn.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Delete_btn.ForeColor = System.Drawing.Color.Black;
            this.Delete_btn.HoverState.Parent = this.Delete_btn;
            this.Delete_btn.Image = global::GUI_QuanLyCafe.Properties.Resources.delete;
            this.Delete_btn.Location = new System.Drawing.Point(157, 405);
            this.Delete_btn.Name = "Delete_btn";
            this.Delete_btn.ShadowDecoration.Parent = this.Delete_btn;
            this.Delete_btn.Size = new System.Drawing.Size(145, 40);
            this.Delete_btn.TabIndex = 45;
            this.Delete_btn.Text = "Xóa món";
            this.Delete_btn.Click += new System.EventHandler(this.Delete_btn_Click);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.NameTable2_lbl);
            this.panel2.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel2.Location = new System.Drawing.Point(3, 457);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(604, 54);
            this.panel2.TabIndex = 44;
            // 
            // NameTable2_lbl
            // 
            this.NameTable2_lbl.AutoSize = true;
            this.NameTable2_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTable2_lbl.Location = new System.Drawing.Point(12, 13);
            this.NameTable2_lbl.Name = "NameTable2_lbl";
            this.NameTable2_lbl.Size = new System.Drawing.Size(56, 24);
            this.NameTable2_lbl.TabIndex = 0;
            this.NameTable2_lbl.Text = "Tên :";
            // 
            // ListOrder2_dgv
            // 
            this.ListOrder2_dgv.AllowUserToResizeColumns = false;
            this.ListOrder2_dgv.AllowUserToResizeRows = false;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.ListOrder2_dgv.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.ListOrder2_dgv.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.ListOrder2_dgv.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.ListOrder2_dgv.BackgroundColor = System.Drawing.Color.White;
            this.ListOrder2_dgv.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SunkenVertical;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.ListOrder2_dgv.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.ListOrder2_dgv.ColumnHeadersHeight = 40;
            this.ListOrder2_dgv.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.ListOrder2_dgv.DefaultCellStyle = dataGridViewCellStyle7;
            this.ListOrder2_dgv.EditMode = System.Windows.Forms.DataGridViewEditMode.EditProgrammatically;
            this.ListOrder2_dgv.Location = new System.Drawing.Point(3, 510);
            this.ListOrder2_dgv.MultiSelect = false;
            this.ListOrder2_dgv.Name = "ListOrder2_dgv";
            this.ListOrder2_dgv.ReadOnly = true;
            this.ListOrder2_dgv.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.ListOrder2_dgv.RowHeadersVisible = false;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ListOrder2_dgv.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.ListOrder2_dgv.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ListOrder2_dgv.ShowCellErrors = false;
            this.ListOrder2_dgv.ShowCellToolTips = false;
            this.ListOrder2_dgv.ShowEditingIcon = false;
            this.ListOrder2_dgv.ShowRowErrors = false;
            this.ListOrder2_dgv.Size = new System.Drawing.Size(604, 310);
            this.ListOrder2_dgv.TabIndex = 43;
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.NameTable1_lbl);
            this.panel1.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(3, 43);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(604, 45);
            this.panel1.TabIndex = 42;
            // 
            // NameTable1_lbl
            // 
            this.NameTable1_lbl.AutoSize = true;
            this.NameTable1_lbl.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTable1_lbl.Location = new System.Drawing.Point(12, 10);
            this.NameTable1_lbl.Name = "NameTable1_lbl";
            this.NameTable1_lbl.Size = new System.Drawing.Size(56, 24);
            this.NameTable1_lbl.TabIndex = 0;
            this.NameTable1_lbl.Text = "Tên :";
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.label1);
            this.panel4.Controls.Add(this.Table_flp);
            this.panel4.Location = new System.Drawing.Point(8, 12);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(653, 824);
            this.panel4.TabIndex = 20;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)));
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Times New Roman", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(189, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(255, 32);
            this.label1.TabIndex = 18;
            this.label1.Text = "DANH SÁCH BÀN";
            // 
            // Table_flp
            // 
            this.Table_flp.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Table_flp.AutoScroll = true;
            this.Table_flp.Font = new System.Drawing.Font("Times New Roman", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table_flp.Location = new System.Drawing.Point(28, 51);
            this.Table_flp.Name = "Table_flp";
            this.Table_flp.Size = new System.Drawing.Size(596, 766);
            this.Table_flp.TabIndex = 17;
            // 
            // ListTable_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1284, 839);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel4);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.MinimumSize = new System.Drawing.Size(16, 790);
            this.Name = "ListTable_frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh sách bàn";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.ListTable_frm_FormClosing);
            this.Load += new System.EventHandler(this.DetachTable_frm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ListOrder1_dgv)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ListOrder2_dgv)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView ListOrder1_dgv;
        private System.Windows.Forms.Panel panel3;
        private Guna.UI2.WinForms.Guna2Button Switch_btn;
        private Guna.UI2.WinForms.Guna2Button Merge_btn;
        private Guna.UI2.WinForms.Guna2Button Detach_btn;
        private Guna.UI2.WinForms.Guna2Button Delete_btn;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label NameTable2_lbl;
        private System.Windows.Forms.DataGridView ListOrder2_dgv;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label NameTable1_lbl;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.FlowLayoutPanel Table_flp;
        private System.Windows.Forms.Label label1;
    }
}