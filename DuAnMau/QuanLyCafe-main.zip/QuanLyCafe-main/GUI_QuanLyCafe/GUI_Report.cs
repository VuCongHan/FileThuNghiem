﻿using CrystalDecisions.CrystalReports.Engine;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GUI_QuanLyCafe
{
    public partial class Report_frm : Form
    {
        public Report_frm()
        {
            InitializeComponent();
        }

        private void Report_frm_Load(object sender, EventArgs e)
        {

        }
    }
}
